﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CodeExamples.Paterns
{
    internal class Singleton
    {
    }
}
