﻿import { Fragment } from "react";

const HelloWorld = (props) => {
    return (
        <Fragment>
            HelloWorld!
        </Fragment>
    )
};

export default HelloWorld;