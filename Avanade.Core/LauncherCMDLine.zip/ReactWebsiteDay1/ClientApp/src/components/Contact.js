﻿import { Fragment } from "react";

const ContactUs = (props) => {
    return (
        <div>
            Contact Us Now
            161 Collins St Melbourne 3000
        </div>
    );
};

export default ContactUs;